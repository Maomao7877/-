<?php

namespace App\models;

use Illuminate\Database\Eloquent\Model;

class user extends Model
{
    protected $table = "l_user";
    public $timestamps = false;
}
