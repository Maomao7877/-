<?php

namespace App\Http\Controllers\Login;

use Illuminate\Http\Request;
use APP\models\user;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;

class LoginController extends Controller
{
    public function register(){
    	return view('Login\register');
    }
//虚拟发送验证码
	/*public function t1(Request $request){
		$obj = new \send();
		$tel = '13716192702';
		$obj->show($tel);
	}*/

//验证码配置
	public function getCode(Request $request){
		$tel = $request->input('tel');
		$num = rand(1000,9999);
		$obj = new \send();
		$bol = $obj->show($tel,$num);

		if($bol==100){
			$arr = array(
				'tel'=>$tel,
				'code'=>$num,
				'timeout'=>time()+240,
				'status'=>1,
			);
			$bol = DB::table('code')->insert($arr);
			$arr1 = array(
				'status'=>0,
				'msg'=>'验证码发送成功'
			);
			return $arr1;
		}else{
			$arr2 = array(
				'status'=>1,
				'msg'=>'验证码发送失败'
			);
			return $arr2;
		}
	}

//验证密码是否一致
    public function regis(Request $request){
    	$data = $request->input();
    	//print_r($data);
    	$tel = $data['tel'];
    	$pwd = md5($data['pwd']);
    	$conpwd = md5($data['conpwd']);
    	$code = $data['code'];
    	if($pwd!=$conpwd){
    		return('两次密码不一致');
    	};
	//验证唯一性
    	$bol = DB::table('l_user')->where('tel',$tel)->first();
    	if(!empty($bol)){
    		$arr = array(
    			'status'=>1,
    			'msg'=>'已存在',
    		);
    		return $arr;
    	}
	//验证码

		//DB::enableQueryLog();
    	$time = time();
    	$arrInfo = DB::table('code')->select('*')->where('code',$code)->where("tel",$tel)->where("status",1)->get();
    	//dd(DB::getQueryLog());
    	// print_r($code);
    	// print_r($arrInfo);
    	//print_r($arrInfo);
    	// exit;
    	if(empty($arrInfo[0]->id)){
    		$arr = array(
    			'status'=>0,
    			'msg'=>'验证码有误',
    		);
    		return $arr;
    	}

	//入库
    	$res = array(
    		'tel'=>$tel,
    		'pwd'=>$pwd
    	);
    	$sql = DB::table('l_user')->insert($res);
    	if($sql){
    		return array(
    			'status'=>1,
    			'msg'=>'添加成功'
    		);
    	}	
    }

//登陆
    public function login(){
    	return view('Login\login');
    }
   public function add(Request $request){
		$data=$request->input();
		$name=$data['name'];
		$pwd=md5($data['pwd']);
		$where=[
			'tel'=>$name,
			'pwd'=>$pwd
		];
		$arr=DB::table('l_user')->where($where)->first();
		if($arr){
			$id=$arr->id;
			$name=$arr->tel;
			session(['id'=>$id,'name'=>$name]);
			return array(
				'status'=>1,
				'msg'=>"登录成功"
			);
		}else{
			return array(
				'status'=>0,
				'msg'=>"登录失败"
			);
		}
	}
}
