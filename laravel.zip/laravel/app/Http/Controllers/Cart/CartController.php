<?php

namespace App\Http\Controllers\Cart;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;

class CartController extends Controller
{
//购物车展示
    public function cartIndex(Request $request){
    	$id = $request->session()->get('id');
    	$goods_id = $request->input('goods_id');

    	//print_r($goods_id);die;
    	if(session($id)){
    		echo json_encode([
        		'status'=>1,
        		'msg'=>'请先登陆',
        	]);
        } 
    	$data = DB::table('shop_cart')->join('shop_goods','shop_goods.goods_id','=','shop_cart.goods_id')->where(['status'=>1])->get();

    	$where=array(
    		'goods_show'=>1
    	);
    	$show = DB::table('shop_goods')->where($where)->paginate(6);
    	//print_r($show);die;
    	return view('cart\cartIndex',['data'=>$data,'show'=>$show]);
    }
//修改购物车数量
    public function upnum(Request $request){
    	$cart_id = $request->input('cart_id');//cate_id
    	$goods_num = $request->input('goods_num');//商品总库存
    	// print_r($cart_id);print_r($goods_num);die;
    	$num = $request->input('num');//框里面的数据
    	// print_r($cart_id);print_r($goods_num);print_r($num);die;
    	// 根据条件进行数据的查询
    	// $goodsdata = DB::table('shop_cart')->where('cart_id',$cart_id)->get(['goods_id']);
    	$where =array(
    		'cart_id'=>$cart_id
    	);
    	if($num>$goods_num){
    		$data = DB::table('shop_cart')->where($where)->update(['buy_number'=>$goods_num]);
    		return '1';
    	}else if($num<1){
    		$data = DB::table('shop_cart')->where($where)->update(['buy_number'=>1]);
    		return 2;
    	}else{
    		$data = DB::table('shop_cart')->where($where)->update(['buy_number'=>$num]);
    	}
    	
    	//print_r($data);
    }
//单删
    public function del(Request $request){
    	$goods_id = $request->input('goods_id');
    	$data = DB::table('shop_cart')->where('goods_id',$goods_id)->update(['status'=>0]);
    	if($data){
    		return '1';
    	}else{
    		return '0';
    		/*'status'=>1,
    		'msg'=>'删除失败',*/
    	}
    }
//批删
    public function delete(Request $request){
    	$cart_id = $request->input('cart_id');
    	//print_r($cart_id);
    	foreach($cart_id as $k=>$v){
    		$data = DB::table('shop_cart')->where('cart_id',$v)->update(['status'=>0]);
    	}
    	if($data){
    		return '1';
    	}else{
    		return '0';
    		/*'status'=>1,
    		'msg'=>'删除失败',*/
    	}
    }
//结算
    public function pay(Request $request){
    	$id = $request->session()->get('id');
    	$goods_id = $request->input('goods_id');
    	$prices = $request->input('price');
    	$price = ltrim($prices,'￥');
    	//print_r($id);
    	if(!$id){
    		return $arr=array(
    			'status'=>'0',
    			'msg'=>'请先登陆',
    		);
    	}
    	if($goods_id==''){
    		return $arr=array(
    			'status'=>'1',
    			'msg'=>'请选择要购买的商品',
    		);
    	}else{
			//print_r($v);die;
			// DB::enableQueryLog();
			$data = DB::table('shop_cart')->join('shop_goods','shop_goods.goods_id','=','shop_cart.goods_id')->whereIn('shop_goods.goods_id',$goods_id)->get()->toArray();
			// dd(DB::getQueryLog());
			//print_r($data);die;
			
			$name=[];
			$goods_num=[];
	    	foreach ($data as $k=>$v) {
	    		if($v->is_tell==0){
	    			$name[]=$v->goods_name;
	    		}
	    		if($v->buy_number>$v->goods_num){
	    			$goods_num[]=$v->goods_name;
	    		}
			}
			$name=implode(',',$name);
			$goods_num=implode(',',$goods_num);
			/*print_r($name);
			print_r($goods_num);die;*/
			if($name!=''){
				return $arr=array(
					'status'=>0,
					'msg'=>$name.'已下架'
				);
			}
			if($goods_num!=''){
				return $arr=array(
					'status'=>0,
					'msg'=>$num.'库存不足'
				);
			}
    		$id = $request->session()->get('id');

			$order_sn=date('YmdHis',time()).rand(11111,99999);
			$ins=[];
			$ins['id']=$id;
			$ins['order_amount']=$price;
			//print_r($price);
			$ins['order_sn']=$order_sn;
			$ins['order_pay_type']=1;
			$ins['pay_status']=1;
			$ins['status']=0;
			$ins['pay_way']=1;
			$insert=DB::table('shop_order')->insertGetId($ins);

			session(['order_id'=>$insert]);
			// $order = DB::table('shop_order_detail')->get();
			if($insert){
				foreach ($data as $k=>$v){
					$data2=[
						'order_id'=>$insert,
						'goods_id'=>$v->goods_id,
						'goods_name'=>$v->goods_name,
						'order_sn'=>$order_sn,
						'id'=>$id,
						'buy_number'=>$v->buy_number,
						'goods_price'=>$v->goods_price,
						'ctime'=>time()
					];
					//print_r($data2);die;
					$data3=DB::table('shop_order_detail')->insert($data2);

					//print_r($data2);die;
		        }
			$up = DB::table('shop_cart')->whereIn('goods_id',$goods_id)->update(['status'=>0]);
            
			}
			// print_r($order);die;
    	}
         $arr=[
                    'status'=>2,
                    'msg'=>'库存不足',
                    'url'=>$order_sn,
                ];
         return $arr;

    }
}
