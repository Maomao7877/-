<?php

namespace App\Http\Controllers\Category;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;

class CategoryController extends Controller
{
	protected static $arrCate;
//分类首页
    public function index(){
    	$arr = DB::table('shop_category')->where('pid',0)->get();
    	$data = DB::table('shop_goods')->get();
    	if($data){
    		$data = DB::table('shop_goods')->get()->toArray();
    	}else{
    		$data = DB::table('shop_goods')->get();
    	}
    	//print_r($data);
    	return view('category\category',['arr'=>$arr,'data'=>$data]);
    }
//根据分类ID查分类数据调取并替换分类下的View页面
    public function category(Request $request){
        $cate_id = $request->input('cate_id');
        $data1 = DB::table('shop_goods')->where('cate_id',$cate_id)->get();
        //print_r($data1);
        $this->categoryto($cate_id);

        $arr = self::$arrCate;
        array_unshift($arr,$cate_id);
        $info=DB::table('shop_goods')->whereIn('cate_id',$arr)->get();
		$view=view('category.all',['info'=>$info]);
        $content=response($view)->getContent();
        $arr['info']=$content;
        return $arr;
    }
//分类替换View层
    private function categoryto($cate_id){
        $data1 = DB::table('shop_category')->select('cate_id')->where('pid',$cate_id)->get();
        if(count($data1)!=0){
			foreach($data1 as $k=>$v){
				$cateId=$v->cate_id;
				$Ids=$this->categoryto($cateId);
				self::$arrCate[]=$Ids;
			}
		}
		if(count($data1)==0){
			return $cate_id;
		}
    }
//接值传给详情页
    public function content(Request $request){
    	$goods_id = $request->input('goods_id');
    	//print_r($goods_id);
    	$where=array(
    		'goods_id'=>$goods_id,
    	);
    	$data = DB::table('shop_goods')->where($where)->first();
    	return view('category\content',['data'=>$data]);
    }

//加入购物车
    public function cart(Request $request){
        $goods_id = $request->input('id');
        //print_r($goods_id);die;
        $data1 = DB::table('shop_goods')->where('goods_id',$goods_id)->first();
        //print($data1);die;
        if($data1){
        	$id = $request->session()->get('id');
        	if(session($id)){
        		echo json_encode([
	        		'status'=>1,
	        		'msg'=>'请先登陆',
	        	]);
	        }else{
	        	$goods_show=$data1->goods_show;
	        	if($goods_show!=1){
	        		echo json_encode([
	        			'status'=>2,
	        			'msg'=>'商品已下架',
	        		]);
	        	}else{
		        	$where=[
		        		'goods_id'=>$goods_id,
		        		'id'=>$id,
		        	];
		        	$cart = DB::table('shop_cart')->where($where)->first();
		        	if($cart){
		        		$buy_number = $cart->buy_number;
		        		$num = $buy_number+1;
		        		$goods_num = $data1->goods_num;
		        		if($num>$goods_num){
		        			echo json_encode([
		        				'status'=>1,
		        				'msg'=>'库存不足',
		        			]);
		        		}else{
                            $cart= DB::table('shop_cart')->where($where)->update(['buy_number'=>$num]);
                            echo json_encode([
                                'status'=>0,
                                'msg'=>'添加成功'
                            ]);
                        }
		        	}else{
                        $data=[];
                        $data['goods_id']=$goods_id;
                        $data['id']=$id;
                        $data['buy_number']=1;
                        $data['ctime']=time();
                        DB::table('shop_cart')->insert($data);
                        echo json_encode([
                            'status'=>0,
                            'msg'=>'添加成功'
                        ]);
                    } 
	        	}
	        }
        }else{
            echo json_encode([
                'status'=>1,
                'msg'=>'没有该商品'
            ]);
        }
	}

}


