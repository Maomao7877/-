<?php

namespace App\Http\Controllers\Index;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;

class IndexController extends Controller
{
//热门推荐、猜你喜欢
    public function index(){
    	$data = DB::table('shop_goods')->limit(2)->get();
    	if($data){
    		$data = DB::table('shop_goods')->limit(2)->get()->toArray();
    	}else{
    		$data = DB::table('shop_goods')->limit(2)->get();
    	}
    	return view('index\index',['data'=>$data]);
    }

//瀑布流
    public function addli(Request $request){
        $arr=array();
        $page=$request->input("page",1);
        $pageNum=2;
        $offset=($page-1)*$pageNum;
        $arrDataInfo=DB::table("shop_goods")->offset($offset)->limit($pageNum)->get();//每页的数据

        $totalData=DB::table("shop_goods")->count();
        $pageTotal=ceil($totalData/$pageNum);//总页数

        $objview=view("index\goodsli",['info'=>$arrDataInfo]);
        $content=response($objview)->getContent();

        $arr['info']=$content;
        $arr['page']=$pageTotal;
        return $arr;
    }
    

    public function add(){
    	echo 'add方法';
    }

    public function show(){
    	echo 'show方法';
    }
}
