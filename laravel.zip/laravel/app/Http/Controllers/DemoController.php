<?php

namespace App\Http\Controllers;
header("content-type:text/html;charset=utf-8");

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class DemoController extends Controller
{
    public function index(Request $request){
    	/*$id = $request->input('id');
    	$name = $request->input('name');
    	echo $id;
    	echo $name;*/
    	//return view('demo');
    	$data = DB::table('apo')->get();
    	return view('demo', ['data' => $data]);
    }

//添加
    public function adddo(Request $request){
    	$data = $request->input();
    	print_r($data);
    	$sql = DB::table('god')->insert($data);
    	if($sql==1){
    		return '1';
    	}else{
    		return '2';
    	}
    	//print_r($sql);
    }

//展示（每页展示5条）
    public function show(){
    	// $select = "select * from god";
    	// $data = DB::select($select);
    	//print_r($data);
    	
    	$data = DB::table('god')->paginate(5);
    	foreach($data as $k=>$v){
    		if($v->is_hot==1){
    			$data[$k]->is_hot='热卖';
    		}else{
    			$data[$k]->is_hot='淡季';
    		}
    		if($v->is_sale==0){
    			$data[$k]->is_sale='已上架';
    		}else{
    			$data[$k]->is_sale='已下架';
    		}
    	}
    	return view('show')->with(['data'=>$data]);
    }

//删除
    public function del(Request $request){
    	$data = $request->input('id');
    	// print_r( $data);
    	$sql = DB::table('god')->where('id',$data)->delete();
    	//print_r($sql);
    	if($sql){
    		echo '2';
    	}else{
    		echo '1';
    	}
    }

//即点即改
    public function update(Request $request){
    	$data = $request->input('id');
    	$new_data = $request->input('name');
    	// print_r($new_data);exit;
    	$sql = DB::table('god')->where('id',$data)->update(['name'=>$new_data]);
    	if($sql){
    		echo '1';
    	}else{
    		echo '2';
    	}
    }

    public function insert(){
    //添加
    	/*$insert = "insert into goods set j_id='2',goods_price='88',goods_num='8',goods_money='66'";
    	$sql = DB::insert($insert);
    	print_r($sql);*/
    //查询
    	/*$select = "select * from goods";
    	$sql = DB::select($select);
    	print_r($sql);*/
    //修改
    	/*$update = "update goods set goods_num=100";
    	$sql = DB::update($update);
    	print_r($sql);*/
    //删除
    	/*$delete = "delete from goods where goods_id='1'";
    	$sql = DB::delete($delete);
    	print_r($sql);*/
    }
}
