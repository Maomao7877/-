<?php

namespace App\Http\Controllers\Pay;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;

class PayController extends Controller
{
//结算首页
    public function payIndex(Request $request){
        $order_id=session('order_id');
        // echo $order_id;die;
    	$data=DB::table('shop_order_detail')->where('order_id',$order_id)->get();
    	return view('pay\payIndex',['data'=>$data]);  
    }
//订单详情
    public function orderList(Request $request){
        $url = $_GET['url']?$_GET['url']:'';
    	$id = $request->session()->get('id');
        //echo $id;
        $order_id=session('order_id');
    	//print_r($id);
    	
    	if(session($id)){
    		echo json_encode([
    			'status'=>1,
    			'msg'=>'请先登陆'
    		]);
    	} 

    	$data = DB::table('shop_order_address')->where('id',$id)->where('address_status',1)->where('is_default',1) ->get();
        // print_r($data);die;
    	$arr = DB::table('shop_order_detail')->where('id',$id)->where('order_sn',$url)->get();
    	return view('pay\orderlist',['data'=>$data,'arr'=>$arr]);
    }

    public function addressList(Request $request){
    	$id = $request->session()->get('id');
    	$consignee_name = $request->input('consignee_name');
    	$consignee_tel = $request->input('consignee_tel');
    	$address_name = $request->input('address_name');
    	//print_r($id);
    	
    	if(session($id)){
    		echo json_encode([
    			'status'=>1,
    			'msg'=>'请先登陆'
    		]);
    	}
    	
    	$data = DB::table('shop_order_address')->where('id',$id)->where('address_status',1)->get();

    	return view('pay\addressList',['data'=>$data]);
    }

    public function del(Request $request){
    	// echo 2345;die;
    	$address_id = $request->input();
    	//print_r($address_id);
    	$del = DB::table('shop_order_address')->where('address_id',$address_id)->update(['address_status'=>0]);
    	if($del){
    		echo json_encode([
        		'status'=>1,
        		'msg'=>'删除成功',
        	]);
    	}

    }

    public function upshow(Request $request){
    	$address_id = $request->input('address_id');
    	//print_r($address_id);die;
    	$data = DB::table('shop_order_address')->where('address_id',$address_id)->get()->toArray();
    	//print_r($data);die;
    	return view('pay\upshow',['data'=>$data]);
    }

//提交修改
    public function upsure(Request $request){
    	$sure=$request->input();
    	$data = DB::table('shop_order_address')->where('address_id',$sure['address_id'])->update($sure);
    	//print_r($data);die;
    	if($data){
    		echo json_encode([
        		'status'=>1,
        		'msg'=>'保存成功',
        	]);
    	}
    }
//更改默认地址
    public function is_default(Request $request){
    	$is_default = $request->input('is_default');
    	$address_id = $request->input('address_id');
    	//print_r($is_default);die;
    	//print_r($address_id);die;
    	$data = DB::table('shop_order_address')->where('address_status',1)->update(['is_default'=>0]);
    	//print_r($data);die;
    	$res = DB::table('shop_order_address')->where('address_status',1)->where('address_id',$address_id)->update(['is_default'=>1]);

    	if($res){
    		echo json_encode([
    			'status'=>1,
    			'msg'=>'默认地址已更改',
    		]);
    	}
    }
//添加地址页面
    public function inaddressList(){
    	return view('pay\inaddressList');
    }

//添加地址执行
    public function inaddress(Request $request){
    	$id = $request->session()->get('id');
    	$insert = $request->input();
    	//print_r($id);die;
    	$into = array(
    		'id'=>$id,
    		'consignee_name'=>$insert['consignee_name'],
    		'address_name'=>$insert['address_name'],
    		'consignee_tel'=>$insert['consignee_tel'],
    		'address_status'=>1,
    		'is_default'=>0,
    	);
    	$data = DB::table('shop_order_address')->insert($into);
    	//print_r($data);die;
    	if($data){
    		echo json_encode([
    			'status'=>1,
    			'msg'=>'添加成功',
    		]);
    	}
    }
}
