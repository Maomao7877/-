<?php
	header("content-type:text/html;charset=utf-8");
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Laravel练习表单</title>
</head>
<body>
	<form id="form">
		<table>
			<tr>
				<td>名称</td>
				<td><input type="text" id="name" name="name"></td>
			</tr>
			<tr>
				<td>分类</td>
				<td>
					<select name="a_id">
						<?php foreach ($data as $k => $v){?>
							<option id="music" value="<?php echo $v->a_id?>">
								<?php echo $v->a_name?>
							</option>
						<?php } ?>
					</select>
				</td>
			</tr>
			<tr>
				<td>描述</td>
				<td><input type="text" id="describe" name="describe"></td>
			</tr>
			<tr>
				<td>是否热卖</td>
				<td>
					<input type="radio" name="is_hot" value="0">是
					<input type="radio" name="is_hot" value="1">否
				</td>
			</tr>
			<tr>
				<td>是否上架</td>
				<td>
					<input type="radio" name="is_sale" value="0">是
					<input type="radio" name="is_sale" value="1">否
				</td>
			</tr>
			<tr>
				<td></td>
				<td><input type="button" id="button" name="button" value="提交"></td>
			</tr>
		</table>
	</form>
</body>
</html>

<script src="/js/jquery.js"></script>
<script>
	$('#button').click(function(){
		var data = $('#form').serialize();
		//console.log(data);
		$.ajax({
			method:"POST",
			url:"adddo",
			data:data,
		}).done(function(msg){
			//alert(msg);
			if(msg==1){
				alert('添加失败');
			}else{
				alert('添加成功');
				window.location.href="show";
			};
		});
	})
</script>