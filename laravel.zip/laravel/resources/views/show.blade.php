<table border="1">
	<tr>
		<td>名称</td>
		<td>分类</td>
		<td>描述</td>
		<td>是否热卖</td>
		<td>是否上架</td>
		<td>修改</td>
		<td>删除</td>
	
	</tr>
	@foreach($data as $v)
		<tr>
			<td><input type="text" name="up" value="{{$v->name}}" id="{{$v->id}}"></td>
			<td>{{$v->a_id}}</td>
			<td>{{$v->describe}}</td>
			<td>{{$v->is_hot}}</td>
			<td>{{$v->is_sale}}</td>
			<td></td>
			<td>
				<a href="javascript:;" name="del" id="{{$v->id}}">删除</a>
			</td>
		</tr>
	@endforeach
</table>
<div>{{$data->links()}}</div>
<!-- 分页页码 -->

<script src="/js/jquery.js"></script>
<script>

//删除
	$('a[name=del]').click(function(){
		var _this=$(this);
		var id=$(this).prop('id');
 		$.post('del',{id:id},function(res){
            if(res==2){
                alert('删除成功');
                _this.parents('tr').remove();
            }else{
                alert('删除失败');
            }
        });
	});

//即点即改
	$('input[name=up]').blur(function(){
		var _this=$(this);
		var id=$(this).prop('id');
		//console.log(id);
		var name=$(this).val();
		//console.log(name);
		$.post('update',{id:id,name:name},function(msg){
			if(msg==1){
				alert('修改成功');
			}else{
				alert('修改失败');
			}
		})
	});

</script>