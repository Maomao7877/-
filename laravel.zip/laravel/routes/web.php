<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|  
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});
/**
 * 域名后面追加 ‘hello’输出‘Return’中的内容
 */
Route::get('hello',function(){
	return 'Routes\web.php 中配置路由';

/*	for($a=1;$a<=20;$a++){
		for($b=1;$b<intval(100/3);$b++){
			for($c=1;$c<intval(100*3);$c++){
				if($a+$b+$c==100&&5*$a+3*$b+$c/3==100){
					echo $a;
					echo '<br>';
					echo $b;
					echo '<br>';
					echo $c;
					echo '<hr>';
				}
			}
		}
	}*/

});

/**
 * 域名后面追加‘user’ 访问‘UsersController’类下的‘index’方法
 */
Route::get('user', 'UsersController@index');
Route::get('demo', 'DemoController@index');
Route::get('insert', 'DemoController@insert');
Route::post('adddo','DemoController@adddo');
Route::any('show', 'DemoController@show');
Route::post('del', 'DemoController@del');
Route::any('update', 'DemoController@update');

Route::get('ser/{id}',function($id){
	if($id>2){
		return redirect('http://www.baidu.com');
	}else{

	}
});

Route::prefix('admin')->group(function(){
	Route::get('users',function(){
		return '表前缀';
	});
});


//中间件
Route::get('add','Index\IndexController@add')->Middleware('add');//全局中间件
Route::get('show','Index\IndexController@show');	
Route::post('add','Login\LoginController@add');		//中间件用法

//潮人购
//首页
Route::get('index','Index\IndexController@index');	
//注册
Route::get('register','Login\LoginController@register');
//验证码 静态页面点击触发的方法	
Route::any('getCode','Login\LoginController@getCode');	
//登陆	
Route::get('login','Login\LoginController@login');
//瀑布流嵌套view页面	
Route::post('addli','Index\IndexController@addli');	
//分类首页
Route::get('categoryindex','Category\CategoryController@index');
//根据分类ID查分类数据调取并替换分类下的View页面 即to
Route::post('category','Category\CategoryController@category');
Route::post('categoryto','Category\CategoryController@categoryto');//
//详情页
Route::get('content','Category\CategoryController@content');//
//加入购物车
Route::post('cart','Category\CategoryController@cart');//
//购物车首页
Route::get('cartIndex','Cart\CartController@cartIndex');//
//修改数量
Route::post('upnum','Cart\CartController@upnum');//
//单删
Route::post('del','Cart\CartController@del');//
//批删
Route::post('delete','Cart\CartController@delete');//
//点击结算传值
Route::post('pay','Cart\CartController@pay');//
//支付页面
Route::get('payIndex','Pay\PayController@payIndex');//
//订单详情
Route::get('orderList','Pay\PayController@orderList');//
//地址管理
Route::get('addressList','Pay\PayController@addressList');//
//删除地址
Route::post('del','Pay\PayController@del');//
//修改地址
Route::any('upshow','Pay\PayController@upshow');//
//修改地址传值
Route::post('upsure','Pay\PayController@upsure');//
//更改为默认地址
Route::any('is_default','Pay\PayController@is_default');//
//添加地址页面
Route::get('inaddressList','Pay\PayController@inaddressList');//
//添加地址执行
Route::any('inaddress','Pay\PayController@inaddress');//
