<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>购物车</title>
    <meta content="app-id=518966501" name="apple-itunes-app" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, user-scalable=no, maximum-scale=1.0" />
    <meta content="yes" name="apple-mobile-web-app-capable" />
    <meta content="black" name="apple-mobile-web-app-status-bar-style" />
    <meta content="telephone=no" name="format-detection" />
    <meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate" />
    <meta http-equiv="Pragma" content="no-cache" />
    <meta http-equiv="Expires" content="0" />
    <link href="css/comm.css" rel="stylesheet" type="text/css" />
    <link href="css/cartlist.css" rel="stylesheet" type="text/css" />
</head>
<body id="loadingPicBlock" class="g-acc-bg">
    <input name="hidUserID" type="hidden" id="hidUserID" value="-1" />
    <div>
        <!--首页头部-->
        <div class="m-block-header">
            <a href="/" class="m-public-icon m-1yyg-icon"></a>
            <a href="/" class="m-index-icon">编辑</a>
        </div>
        <!--首页头部 end-->
        <div class="g-Cart-list">
            <ul id="cartBody">

                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li>
                    <s class="xuan current" cart_id="<?php echo e($v->cart_id); ?>" goods_id="<?php echo e($v->goods_id); ?>"></s>
                    <a class="fl u-Cart-img" href="/v44/product/12501977.do">
                        <img src="/goodsimg/<?php echo e($v->goods_img); ?>" border="0" alt="">
                    </a>
                        <div class="u-Cart-r">
                            <a href="/v44/product/12501977.do" class="gray6"><?php echo e($v->goods_name); ?></a>
                            <money style="margin-left:75%" class="text_box"  >￥:<?php echo e($v->goods_price); ?></money>
                            <span class="gray9">
                                <em>剩余124人次</em>
                            </span> 
                            <div class="num-opt">
                                <em class="num-mius dis min addto"  cart_id="<?php echo e($v->cart_id); ?>"><i></i></em>  
                                <input class="text_box" name="num" cart_id="<?php echo e($v->cart_id); ?>" goods_num="<?php echo e($v->goods_num); ?>" goods_price="<?php echo e($v->goods_price); ?>" maxlength="6" type="text" value="<?php echo e($v->buy_number); ?>" codeid="12501977">
                                <em class="num-add add" cart_id="<?php echo e($v->cart_id); ?>"><i></i></em>
                            </div>
                            <a href="javascript:;" name="delLink" cid="12501977" isover="0" class="z-del"  goods_id="<?php echo e($v->goods_id); ?>"><s></s></a>
                        </div> 
                </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
               
            </ul>
            <div id="divNone" class="empty "  style="display: none"><s></s><p>您的购物车还是空的哦~</p><a href="https://m.1yyg.com" class="orangeBtn">立即潮购</a></div>
        </div>
        <div id="mycartpay" class="g-Total-bt g-car-new" style="">
            <dl>
                <dt class="gray6">
                    <s class="quanxuan current"></s>全选
                    <p class="money-total">合计<em class="orange total" price=""><span>￥</span></em></p>
                    
                </dt>
                <dd>
                    <a href="javascript:;" id="a_payment" class="orangeBtn w_account remove del">删除</a>
                    <a href="javascript:;" id="a_payment" class="orangeBtn w_account jiesuan">去结算</a>
                </dd>
            </dl>
        </div>
 
        <div class="hot-recom">
            <div class="title thin-bor-top gray6">
                <span><b class="z-set"></b>人气推荐</span>
                <em></em>
            </div>
            <div class="goods-wrap thin-bor-top">
                <ul class="goods-list clearfix">
                    <?php $__currentLoopData = $show; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                        <a href="https://m.1yyg.com/v44/products/23458.do" class="g-pic">
                            <img src="/goodsimg/<?php echo e($v->goods_img); ?>" width="136" height="136">
                        </a>
                        <p class="g-name">
                            <a href="https://m.1yyg.com/v44/products/23458.do"><?php echo e($v->goods_name); ?></a>
                        </p>
                        <ins class="gray9">价值:￥<?php echo e($v->goods_price); ?></ins>
                        <div class="btn-wrap">
                            <div class="Progress-bar">
                                <p class="u-progress">
                                    <span class="pgbar" style="width:1%;">
                                        <span class="pging"></span>
                                    </span>
                                </p>
                            </div>
                            <div class="gRate" data-productid="23458">
                                <a href="javascript:;"><s></s></a>
                            </div>
                        </div>
                    </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </div>


<div class="footer clearfix">
    <ul>
        <li class="f_home"><a href="/v41/index.do" ><i></i>潮购</a></li>
        <li class="f_announced"><a href="/v41/lottery/" ><i></i>最新揭晓</a></li>
        <li class="f_single"><a href="/v41/post/index.do" ><i></i>晒单</a></li>
        <li class="f_car"><a id="btnCart" href="/v41/mycart/index.do" class="hover"><i></i>购物车</a></li>
        <li class="f_personal"><a href="/v41/member/index.do" ><i></i>我的潮购</a></li>
    </ul>
</div>

<script src="js/jquery-1.11.2.min.js"></script>
<!---商品加减算总数---->
    <script type="text/javascript">
    $(function () {
        $(".add").click(function () {
            var t = $(this).prev();
            t.val(parseInt(t.val()) + 1);

            var data={}
            data.num=t.val();
            data.cart_id=$(this).attr('cart_id');
            data.goods_num=t.attr('goods_num');

            if(data.num>data.goods_num){
                //alert('11111111111');
                t.val(parseInt(t.val()) - 1);
                GetCount();
            }
            //GetCount();
            //alert(data.goods_num);die;
            /*
            if(t.val()>=data.goods_num){
                alert('11111111111');
                t.val(parseInt(t.val()) - 1);
                GetCount();
            }*/

            $.ajax({
                type:"POST",
                data:data,
                url:"upnum",
                dataType:"json",
                success:function(msg){
                    if(msg==1){
                        alert('库存不足')
                        history.go(0);
                        //location.href="/cartIndex";
                    }
                }
            })
        })
        $(".min").click(function () {
            var t = $(this).next();
            if(t.val()>1){
                t.val(parseInt(t.val()) - 1);
                GetCount();
            }
            //t.val(parseInt(t.val())-1);
            var data={}
            data.num=t.val();
            data.cart_id=$(this).attr('cart_id');
            data.goods_num=t.attr('goods_num');

            $.ajax({
                type:"POST",
                data:data,
                url:"upnum",
                dataType:"json",
                success:function(msg){

                }
            })
        })
    })

    $(".text_box").blur(function () {
            var data = {};
            var va = $(this).val();
            // $(this).val(v);
            var cate_id = $(this).prev().attr('cart_id');
            var goods_num = $(this).attr('goods_num');
            data.num = va;
            data.cart_id = cate_id;
            data.goods_num = goods_num;

            $.ajax({
                type:"POST",
                data:data,
                url:"upnum",
                dataType:"json",
                success:function(msg){
                    if(msg==1){
                        alert('库存不足')
                        history.go(0);
                        //location.href="/cartIndex";
                    }else if(msg==2){
                        alert('输入的商品数量必须等于或大于1')
                        history.go(0);
                    }
                }
            })
            
        })
    </script>
    
    <script>

    // 全选        
    $(".quanxuan").click(function () {
        if($(this).hasClass('current')){
            $(this).removeClass('current');

             $(".g-Cart-list .xuan").each(function () {
                if ($(this).hasClass("current")) {
                    $(this).removeClass("current"); 
                } else {
                    $(this).addClass("current");
                } 
            });
            GetCount();
        }else{
            $(this).addClass('current');

             $(".g-Cart-list .xuan").each(function () {
                $(this).addClass("current");
                // $(this).next().css({ "background-color": "#3366cc", "color": "#ffffff" });
            });
            GetCount();
        }
    });

    // 单选
    $(".g-Cart-list .xuan").click(function () {
        if($(this).hasClass('current')){
            $(this).removeClass('current');
        }else{
            $(this).addClass('current');
        }
        if($('.g-Cart-list .xuan.current').length==$('#cartBody li').length){
                $('.quanxuan').addClass('current');
            }else{
                $('.quanxuan').removeClass('current');
            }
        // $("#total2").html() = GetCount($(this));
        GetCount();
        //alert(conts);
    });

    //已选中的总额
    function GetCount() {
        var conts = 0;
        var aa = 0; 
        $(".g-Cart-list .xuan").each(function () {
            if ($(this).hasClass("current")) {
                for (var i = 0; i < $(this).length; i++) {
                    var str = parseInt($(this).parents('li').find('input.text_box').val());
                    var price = parseInt($(this).parents('li').find('input.text_box').attr('goods_price'));
                    conts+=parseInt(str*price);
                    //alert(price);
                    // aa += 1;
                }
            }
        });
        //console.log(conts);
        
         $(".total").html('<span>￥</span>'+(conts).toFixed(2));
    }
    GetCount();
</script>
</body>
</html>

<script>
//单删
    $('.z-del').click(function(){
        var data={}
        data.goods_id=$(this).attr('goods_id');
        //console.log(data.goods_id);
        $.ajax({
            type:"POST",
            data:data,
            url:'del',
            dataType:'json',
            success:function(msg){
                //console.log('111');
                if(msg==1){
                    alert('删除成功');
                    history.go(0);
                }else{
                    alert('删除失败');
                }
            }
        })
    })

//批删
    $('.del').click(function(){
        //alert(11);
        var cart_id=[];
        $(".g-Cart-list .xuan").each(function () {
            if ($(this).hasClass("current")) {
                for (var i = 0; i < $(this).length; i++) {
                    cart_id.push($(this).attr('cart_id'))
                }
            }
        });

        var data={}
        data.cart_id=cart_id;
        $.ajax({
            type:'POST',
            data:data,
            url:'delete',
            dataType:'json',
            success:function(msg){
                if(msg==1){
                    alert('删除成功');
                    history.go(0);
                }else{
                    alert('删除失败');
                }
            }
        })
    })

//结算
    $('.jiesuan').click(function(){
        //alert(11);
        var goods_id=[];
        var price=$(".orange.total").text();
        $(".xuan.current").each(function () {
            if ($(this).hasClass("current")) {
                goods_id.push($(this).attr('goods_id'));
            }
        });
        //alert(goods_id);
        var data={}
        data.goods_id=goods_id;
        data.price=price;
        //alert(data.goods_id);die;
        $.ajax({
            type:'POST',
            data:data,
            url:'pay',
            dataType:'json',
            success:function(res){
                //console.log(status);
                if(res.status==0){
                    alert(res.msg);
                    window.location.href='login';
                }
                if(res.status==1){
                    alert(res.msg);
                    history.go(0);
                }else if(res.status==2){
                    window.location.href="orderList?url="+res.url;
                }
                
            }
        })
    })

</script>
