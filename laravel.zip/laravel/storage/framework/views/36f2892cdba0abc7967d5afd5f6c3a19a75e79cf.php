<!DOCTYPE html>
<html>
<head>
    <meta content="text/html; charset=utf-8" http-equiv="Content-Type" />
    <title>地址管理</title>
    <meta content="app-id=984819816" name="apple-itunes-app" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, user-scalable=no, maximum-scale=1.0" />
    <meta content="yes" name="apple-mobile-web-app-capable" />
    <meta content="black" name="apple-mobile-web-app-status-bar-style" />
    <meta content="telephone=no" name="format-detection" />
    <link href="css/comm.css" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" href="css/address.css">
    <link rel="stylesheet" href="css/sm.css">
  
   
    
</head>
<body>
    
<!--触屏版内页头部-->
<div class="m-block-header" id="div-header">
    <strong id="m-title">地址管理</strong>
    <a href="javascript:history.back();" class="m-back-arrow"><i class="m-public-icon"></i></a>
    <a href="/inaddressList" class="m-index-icon into">添加</a>
</div>
<div class="addr-wrapp">
	<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="addr-list">
         <ul>
            <li class="clearfix">
                <span class="fl" cname="<?php echo e($v->consignee_name); ?>" ><?php echo e($v->consignee_name); ?></span>
                <span class="fr" ctel="<?php echo e($v->consignee_tel); ?>"><?php echo e($v->consignee_tel); ?></span>
            </li>
            <li>
                <p  aname="<?php echo e($v->address_name); ?>"><?php echo e($v->address_name); ?></p>
            </li>
            <li class="a-set">

	    		<?php if($v->is_default==1): ?>
	                <s class="z-set" is_default="<?php echo e($v->is_default); ?>" address_id="<?php echo e($v->address_id); ?>" style="margin-top: 6px;"></s>
	                <span>设为默认</span>
	            <?php else: ?>
	            	<s class="z-defalt" is_default="<?php echo e($v->is_default); ?>" address_id="<?php echo e($v->address_id); ?>" style="margin-top: 6px;"></s>
	                <span class="defalt">设为默认</span>
				<?php endif; ?>

                <div class="fr">
                    <span class="edit" address_id="<?php echo e($v->address_id); ?>">编辑</span>
                    <span class="remove" address_id="<?php echo e($v->address_id); ?>">删除</span>
                </div>
            </li>
        </ul>  
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<script src="js/zepto.js" charset="utf-8"></script>
<script src="js/sm.js"></script>
<script src="js/sm-extend.js"></script>


<!-- 单选 -->
<script>
    

     // 删除地址
    /*$(document).on('click','span.remove', function () {
        var buttons1 = [
            {
              text: '删除',
              bold: true,
              color: 'danger',
              onClick: function() {
                $.alert("您确定删除吗？");
              }
            }
          ];
          var buttons2 = [
            {
              text: '取消',
              bg: 'danger'
            }
          ];
          var groups = [buttons1, buttons2];
          $.actions(groups);
    });*/
//删除
    $('.remove').click(function(){
    	var arr={}
    	arr.address_id=$(this).attr('address_id');
    	//alert(arr.address_id);
    	$.ajax({
    		type:'POST',
    		url:'del',
    		data:arr,
    		dataType:'json',
    		success:function(msg){
    			if(msg.status==1){
    				alert(msg.msg);
    				history.go(0);
    			}else{
    				alert('删除失败');
    			}
    		}
    	})
    })
//传值到修改地址页面
    $('.edit').click(function(){
    	var address_id=$(this).attr('address_id');
    	window.location.href="/upshow?address_id="+address_id;
    	
    })

//传值到添加地址页面
    /*$('.into').click(function(){
    	var address_id=$(this).attr('address_id');
    	window.location.href="/upshow?address_id="+address_id;
    	
    })*/

//修改默认值
	$('.z-defalt').click(function(){
		var res={}
		res.is_default=$(this).attr('is_default');
		res.address_id=$(this).attr('address_id');

		$.ajax({
			type:'POST',
			data:res,
			url:'is_default',
			dataType:'json',
			success:function(msg){
				if(msg.status==1){
					history.go(0);
				}else{
					alert('更改失败');
				}
			}
		})
	})
</script>
<script src="js/jquery-1.8.3.min.js"></script>
<script>
    /*var $$=jQuery.noConflict();
    $$(document).ready(function(){
            // jquery相关代码
            $$('.addr-list .a-set s').toggle(
            function(){
                if($$(this).hasClass('z-set')){
                    
                }else{
                    $$(this).removeClass('z-defalt').addClass('z-set');
                    $$(this).parents('.addr-list').siblings('.addr-list').find('s').removeClass('z-set').addClass('z-defalt');
                }   
            },
            function(){
                if($$(this).hasClass('z-defalt')){
                    $$(this).removeClass('z-defalt').addClass('z-set');
                    $$(this).parents('.addr-list').siblings('.addr-list').find('s').removeClass('z-set').addClass('z-defalt');
                }
                
            }
        )

    });*/
    
</script>



</body>
</html>
